## produce_gt.sh
 
#!/bin/bash
 
echo "## Kafka Producer ##"
 
cat gt.csv | while read line; do
 
	echo "$line"
 
	sleep 0.1
 
done 

#| /bin/kafka-console-producer --topic test1 --bootstrap-server rpc:19092,rpc,:29092,rpc:39092
